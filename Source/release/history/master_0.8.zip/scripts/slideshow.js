// Type your script code here...
slideshow = {
	category: "",
	reset: true
}

// Set category
slideshow.setCategory = function(catName) {
	this.category = catName;
};